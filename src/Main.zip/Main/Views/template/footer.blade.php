<footer class="footer footer-static footer-light navbar-border">
  <p class="clearfix text-muted text-sm-center mb-0 px-2"><span class="float-md-left d-xs-block d-md-inline-block">
    {!! setting('admin.copyright', '&copy; '.date('Y').' ' . setting('site.title')) !!}
  </p>
</footer>