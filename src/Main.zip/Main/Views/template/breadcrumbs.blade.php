<!-- START JUMBOTRON -->
<div class="jumbotron" data-pages="parallax">
<?php /*
	<div class=" container-fluid container-fixed-lg sm-p-l-0 sm-p-r-0">
	  <div class="inner">
	    <!-- START BREADCRUMB -->
	     <ol class="breadcrumb">
	      <li class="breadcrumb-item"><a href="#">Barebone</a></li>
	      <li class="breadcrumb-item active">Layout</li>
	    </ol>
	    <!-- END BREADCRUMB --> 
	  </div>
	</div>
*/ ?>	
</div>
<!-- END JUMBOTRON -->		
