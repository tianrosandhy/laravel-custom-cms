<div class="modal fade fill-in" id="defaultModal" tabindex="-1" role="dialog" aria-hidden="true">
	<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="fa fa-times"></i></button>
	<div class="modal-dialog ">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="text-left p-b-5 default-modal-title"></h5>
			</div>
			<div class="modal-body default-modal-content">

			</div>
		</div>
	</div>
</div>

<div class="modal fade fill-in" id="alertModal" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog ">
		<div class="modal-content">
			<div class="modal-header">
				<div class="alert-title pull-left">
					<h5 class="text-uppercase"></h5>
				</div>
				<div class="pull-right float-right">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				</div>
			</div>
			<div class="modal-body alert-modal-content">
			</div>
		</div>

	</div>

</div>

@stack ('modal')
@stack ('modals')