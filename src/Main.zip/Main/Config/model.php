<?php
//List of Models initials in Website
//bisa dipake di CrudRepository

return [
	'user' => 'Module\Main\Models\User',
	'role' => 'Module\Main\Models\Role',

	'setting_structure' => 'Module\Base\Models\SettingStructure',
	'translator' => 'Module\Main\Models\Translator',

];