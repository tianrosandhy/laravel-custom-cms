<?php
return [
	'main' => [
		'upload_path' => 'default',
	],
	'user' => [
		'upload_path' => 'user',
		'export_excel' => true
	],

];